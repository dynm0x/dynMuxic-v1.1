package com.dynmox.pixelplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max

private val Ink = Color(0xFF121212)
private val Card = Color(0xB822242A)
private val Blue = Color(0xFF1ED760)
private val PaleBlue = Color(0xFF1ED760)
private val Warm = Color(0xFF193D2A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PixelPlayerApp() }
    }
}

@Composable
private fun PixelPlayerApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(context).build() }
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var current by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf("Playlists") }
    var screen by remember { mutableStateOf("Library") }
    var automix by remember { mutableStateOf(true) }
    var lightMode by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    var playlists by remember { mutableStateOf(emptyList<String>()) }
    var crossfade by remember { mutableFloatStateOf(5f) }
    var isPlaying by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var lastTrack by remember { mutableIntStateOf(-1) }
    var fading by remember { mutableStateOf(false) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                current = max(0, player.currentMediaItemIndex)
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    fun playTrack(index: Int, list: List<Track> = tracks) {
        if (list.isEmpty()) return
        val safeIndex = index.coerceIn(0, list.lastIndex)
        current = safeIndex
        player.setMediaItems(list.map { MediaItem.fromUri(it.uri) }, safeIndex, 0L)
        player.prepare()
        player.play()
        screen = "Player"
    }

    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        if (granted) tracks = MusicRepository.scan(context)
    }
    LaunchedEffect(hasPermission) {
        if (hasPermission) tracks = MusicRepository.scan(context)
    }
    LaunchedEffect(player, automix, crossfade) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.takeIf { it > 0 } ?: 0L
            progress = if (duration > 0) position.toFloat() / duration else 0f
            // Gapless automatic queue playback is supported. A true two-track volume crossfade
            // requires two synchronized players; this starter keeps the setting visible and saved
            // in UI state while the next implementation step adds the dual-player mixer.
            delay(300)
        }
    }

    MaterialTheme(
        colorScheme = if (lightMode) lightColorScheme(
            background = Color(0xFFF4F6F8), surface = Color(0xBFFFFFFF), primary = Blue,
            onPrimary = Color.Black, onBackground = Color(0xFF171717), onSurface = Color(0xFF171717), secondary = Blue
        ) else darkColorScheme(
            background = Ink, surface = Card, primary = PaleBlue,
            onPrimary = Color.Black, onBackground = Color.White,
            onSurface = Color.White, secondary = Blue
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = if (lightMode) Color(0xFFF4F6F8) else Ink) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth().background(if (lightMode) Color(0xFFE4F5E9) else Color(0xB822242A)).padding(horizontal = 20.dp, vertical = 18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("dynMuxic", color = PaleBlue, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Text("OFFLINE MUSIC", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Text(if (lightMode) "☾" else "☼", color = PaleBlue, fontSize = 28.sp, modifier = Modifier.clickable { lightMode = !lightMode })
                }
                Row(
                    Modifier.fillMaxWidth().background(if (lightMode) Color(0xFFE4F5E9) else Color(0xB822242A)).padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Library", "Player", "Settings").forEach { item ->
                        val selected = screen == item
                        Surface(
                            color = if (selected) PaleBlue else Color(0xFF101010),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier.weight(1f).clickable { screen = item }
                        ) {
                            Text(item, modifier = Modifier.padding(vertical = 12.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                color = if (selected) Color(0xFF172747) else Color.LightGray, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                when (screen) {
                    "Player" -> {
                        Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Box(
                                Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp))
                                    .background(Brush.linearGradient(listOf(Warm, Color(0xFF211713), Color(0xFF090909)))),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("♫", color = PaleBlue, fontSize = 100.sp)
                                    Text("LOCAL FILES", color = Color(0xFFDDC8B9), letterSpacing = 4.sp, fontSize = 12.sp)
                                }
                            }
                            Spacer(Modifier.height(22.dp))
                            Text(tracks.getOrNull(current)?.title ?: "Choose a song", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(tracks.getOrNull(current)?.artist ?: "Your music, offline", color = Color.LightGray, fontSize = 15.sp)
                            Spacer(Modifier.height(18.dp))
                            Slider(value = progress.coerceIn(0f, 1f), onValueChange = { progress = it; if (duration > 0) player.seekTo((duration * it).toLong()) }, colors = SliderDefaults.colors(thumbColor = PaleBlue, activeTrackColor = PaleBlue))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(formatTime(position), color = Color.LightGray, fontSize = 12.sp)
                                Text(formatTime(duration), color = Color.LightGray, fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(18.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                                Text("|◀", fontSize = 25.sp, modifier = Modifier.clickable { if (tracks.isNotEmpty()) playTrack((current - 1 + tracks.size) % tracks.size) })
                                Surface(color = Warm, shape = CircleShape, modifier = Modifier.size(76.dp).clickable {
                                    if (player.mediaItemCount == 0 && tracks.isNotEmpty()) playTrack(current)
                                    else if (player.isPlaying) player.pause() else player.play()
                                }) {
                                    Box(contentAlignment = Alignment.Center) { Text(if (isPlaying) "Ⅱ" else "▶", fontSize = 30.sp) }
                                }
                                Text("▶|", fontSize = 25.sp, modifier = Modifier.clickable { if (tracks.isNotEmpty()) playTrack((current + 1) % tracks.size) })
                            }
                            Spacer(Modifier.height(22.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Automix", color = Color.LightGray)
                                Switch(checked = automix, onCheckedChange = { automix = it })
                                Text("Crossfade ${crossfade.toInt()}s", color = PaleBlue)
                            }
                            Slider(value = crossfade, onValueChange = { crossfade = it }, valueRange = 0f..12f, steps = 11)
                            Text("Local audio only • No streaming • No account", color = Color.Gray, fontSize = 11.sp)
                        }
                    }
                    "Settings" -> {
                        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                            Text("Playback settings", color = PaleBlue, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            CardRow("Automix", "Continue through the current queue") {
                                Switch(checked = automix, onCheckedChange = { automix = it })
                            }
                            Text("Crossfade duration: ${crossfade.toInt()} seconds", fontSize = 17.sp)
                            Slider(value = crossfade, onValueChange = { crossfade = it }, valueRange = 0f..12f, steps = 11)
                            Text("Crossfade overlap still needs a dual-player audio engine; this setting alone does not create a real fade.", color = Color.LightGray, fontSize = 13.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) { Text("Light mode", modifier = Modifier.weight(1f)); Switch(checked = lightMode, onCheckedChange = { lightMode = it }) }
                            Text("Privacy", color = PaleBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Music is read from your device. This app has no internet permission.", color = Color.LightGray)
                        }
                    }
                    else -> {
                        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
                            Text("Library", color = PaleBlue, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Songs", "Albums", "Artists", "Playlists", "Folders").forEach {
                                    FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it, fontSize = 11.sp) })
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            if (!hasPermission) {
                                Text("Allow access to audio files to scan music stored on your phone.", color = Color.LightGray)
                                Button(onClick = { permissionLauncher.launch(permission) }) { Text("Allow local music access") }
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                    Text("${tracks.size} local songs", color = Color.LightGray)
                                    TextButton(onClick = { tracks = MusicRepository.scan(context) }) { Text("Rescan") }
                                }
                                if (tracks.isEmpty()) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("No music found in Music/", color = PaleBlue, fontSize = 22.sp)
                                            Text("Move audio files into your phone’s Music folder, then tap Rescan.", color = Color.LightGray)
                                        }
                                    }
                                } else {
                                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                                        itemsIndexed(tracks, key = { _, t -> t.id }) { index, track ->
                                            Row(
                                                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card)
                                                    .clickable { playTrack(index) }.padding(14.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(Modifier.size(50.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Blue, Color(0xFF28232B)))), contentAlignment = Alignment.Center) {
                                                    Text("♫", fontSize = 25.sp, color = PaleBlue)
                                                }
                                                Spacer(Modifier.width(12.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text(track.artist, color = Color.LightGray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                                Text(formatTime(track.durationMs), color = Color.Gray, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CardRow(title: String, subtitle: String, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
        }
        trailing()
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0) / 1000).toInt()
    return "%d:%02d".format(total / 60, total % 60)
}
