# dynMuxic 1.1 — Android starter update

This update contains a Spotify-inspired green/charcoal palette, translucent panel styling, a basic light/dark appearance toggle, a new launcher icon, and a MediaStore scan limited to audio stored under the device's `Music/` folder. The app remains offline-only and does not request Internet permission.

## Important status
This is still a starter project, not a finished music player. The current crossfade slider is only a UI setting; **true overlapping crossfade has not been implemented yet**. The playlist screen and persistent playlist-to-song assignment are also not fully implemented. Although a MediaSession service scaffold exists, the foreground notification/media controls are not yet properly connected to the UI's active player, so background controls are not guaranteed to work.

The source has not been compiled or device-tested in this environment. Run the GitHub Actions build and test the APK on-device before relying on it.
