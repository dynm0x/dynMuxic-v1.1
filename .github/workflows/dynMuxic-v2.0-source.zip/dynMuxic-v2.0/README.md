# dynMuxic v2.0 — fresh Android project

Package: `com.dynmox.dynmuxic`  
App name: `dynMuxic`  
Tagline: `dynamic. personal. yours.`

## Build on GitHub Actions using an Android phone

1. Create a new GitHub repository named `dynMuxic`.
2. Upload the contents of this project so that `app/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/` are at the repository root.
3. Open **Actions** → **Build dynMuxic v2.0 APK** → **Run workflow**.
4. When the run completes, open it and download the `dynMuxic-v2.0-debug` artifact.
5. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser/file manager.

## Current implementation notes

- Android native Kotlin + Jetpack Compose UI.
- MediaStore query filters to `Music/` relative paths.
- Room database stores playlist records.
- Two ExoPlayer instances are used for an end-of-track crossfade ramp.
- This is a development build, not yet a verified release. Crossfade, playlist editing/track membership, notification controls, and playback edge cases still require device testing and further implementation. The current playlist screen creates and deletes playlists; rename and adding/removing tracks are not complete yet.
- No APK is included in this source archive. GitHub Actions must compile it.
