package com.dynmox.dynmuxic

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.*

/**
 * Two-player crossfade engine.
 * The incoming player starts muted, then both players ramp in opposite directions.
 * This is a first implementation; device-level playback and interruption testing is still required.
 */
class CrossfadeEngine(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val players = listOf(ExoPlayer.Builder(appContext).build(), ExoPlayer.Builder(appContext).build())
    private var active = 0
    private var fadeJob: Job? = null
    var crossfadeMs: Long = 5000L
        set(value) { field = value.coerceIn(0L, 12000L) }

    private val current get() = players[active]
    private val standby get() = players[1 - active]

    fun play(uri: Uri) {
        fadeJob?.cancel()
        players.forEach { it.stop(); it.clearMediaItems(); it.volume = 0f }
        current.volume = 1f
        current.setMediaItem(MediaItem.fromUri(uri))
        current.prepare()
        current.play()
        attachEndListener(current)
    }

    fun setNext(uri: Uri) {
        standby.stop()
        standby.clearMediaItems()
        standby.volume = 0f
        standby.setMediaItem(MediaItem.fromUri(uri))
        standby.prepare()
    }

    private fun attachEndListener(player: ExoPlayer) {
        player.removeListener(endListener)
        player.addListener(endListener)
    }

    private val endListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) beginCrossfade()
        }
    }

    private fun beginCrossfade() {
        if (standby.mediaItemCount == 0) return
        fadeJob?.cancel()
        val outgoing = current
        val incoming = standby
        incoming.seekTo(0)
        incoming.volume = 0f
        incoming.playWhenReady = true
        val duration = crossfadeMs
        if (duration == 0L) {
            outgoing.pause()
            outgoing.volume = 0f
            incoming.volume = 1f
            active = 1 - active
            attachEndListener(current)
            return
        }
        fadeJob = scope.launch {
            val steps = (duration / 50L).coerceAtLeast(1L).toInt()
            repeat(steps + 1) { step ->
                val fraction = step.toFloat() / steps
                outgoing.volume = 1f - fraction
                incoming.volume = fraction
                delay(duration / steps)
            }
            outgoing.stop()
            outgoing.clearMediaItems()
            incoming.volume = 1f
            active = 1 - active
            attachEndListener(current)
        }
    }

    fun pause() = players.forEach { it.pause() }
    fun resume() = current.play()
    fun seekTo(positionMs: Long) = current.seekTo(positionMs)
    fun positionMs(): Long = current.currentPosition
    fun durationMs(): Long = current.duration.coerceAtLeast(0L)
    fun isPlaying(): Boolean = current.isPlaying

    fun release() {
        fadeJob?.cancel()
        scope.cancel()
        players.forEach { it.release() }
    }
}
