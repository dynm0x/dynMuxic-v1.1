package com.dynmox.dynmuxic

import android.content.Context
import androidx.room.*

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val trackIds: String = ""
)

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE")
    suspend fun all(): List<PlaylistEntity>
    @Insert
    suspend fun insert(item: PlaylistEntity): Long
    @Update
    suspend fun update(item: PlaylistEntity)
    @Delete
    suspend fun delete(item: PlaylistEntity)
}

@Database(entities = [PlaylistEntity::class], version = 1, exportSchema = false)
abstract class PlaylistDatabase : RoomDatabase() {
    abstract fun playlists(): PlaylistDao
    companion object {
        @Volatile private var INSTANCE: PlaylistDatabase? = null
        fun get(context: Context): PlaylistDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, PlaylistDatabase::class.java, "dynmuxic.db"
                ).build().also { INSTANCE = it }
            }
    }
}
