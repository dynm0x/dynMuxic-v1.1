package com.dynmox.dynmuxic

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

private val Ink = Color(0xFF090D12)
private val Panel = Color(0xFF18232B)
private val Mint = Color(0xFF42E6B5)

class MainActivity : ComponentActivity() {
    private lateinit var repository: MusicRepository
    private lateinit var engine: CrossfadeEngine
    private lateinit var playlistDao: PlaylistDao
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) scan()
    }
    private var tracks by mutableStateOf<List<Track>>(emptyList())
    private var selected by mutableStateOf<Track?>(null)
    private var playlists by mutableStateOf<List<PlaylistEntity>>(emptyList())
    private var fadeSeconds by mutableFloatStateOf(5f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = MusicRepository(this)
        engine = CrossfadeEngine(this)
        playlistDao = PlaylistDatabase.get(this).playlists()
        lifecycleScope.launch { playlists = playlistDao.all() }
        setContent { DynMuxicScreen() }
        requestMusicPermission()
    }

    private fun requestMusicPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) scan()
        else permission.launch(p)
    }

    private fun scan() { tracks = repository.scanMusicFolder() }

    @Composable
    private fun DynMuxicScreen() {
        var tab by remember { mutableStateOf("Home") }
        var showCreate by remember { mutableStateOf(false) }
        var playlistName by remember { mutableStateOf("") }
        var crossfade by remember { mutableStateOf(false) }
        MaterialTheme(colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Mint, onBackground = Color.White,
            onSurface = Color.White
        )) {
            Scaffold(containerColor = Ink, bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Library", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item },
                            icon = { Icon(if (item == "Home") Icons.Default.Home else if (item == "Library") Icons.Default.LibraryMusic else Icons.Default.Settings, null) },
                            label = { Text(item) }
                        )
                    }
                }
            }) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                    Text("dynMuxic", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, color = Mint)
                    Text("dynamic. personal. yours.", color = Color.LightGray)
                    Spacer(Modifier.height(18.dp))
                    when (tab) {
                        "Home" -> {
                            Text("YOUR MUSIC", color = Mint, style = MaterialTheme.typography.labelLarge)
                            Text("${tracks.size} tracks found in Music/", color = Color.LightGray)
                            Spacer(Modifier.height(10.dp))
                            LazyColumn(Modifier.weight(1f)) {
                                items(tracks, key = { it.id }) { track ->
                                    TrackRow(track, selected?.id == track.id) {
                                        selected = track
                                        engine.play(track.uri)
                                    }
                                }
                            }
                        }
                        "Library" -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Your playlists", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                                IconButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, "Create playlist", tint = Mint) }
                            }
                            playlists.forEach { playlist ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(playlist.name, Modifier.weight(1f))
                                        IconButton(onClick = {
                                            lifecycleScope.launch { playlistDao.delete(playlist); playlists = playlistDao.all() }
                                        }) { Icon(Icons.Default.Delete, "Delete playlist") }
                                    }
                                }
                            }
                            if (showCreate) AlertDialog(
                                onDismissRequest = { showCreate = false },
                                title = { Text("New playlist") },
                                text = { OutlinedTextField(playlistName, { playlistName = it }, label = { Text("Playlist name") }) },
                                confirmButton = {
                                    TextButton(onClick = {
                                        if (playlistName.isNotBlank()) lifecycleScope.launch {
                                            playlistDao.insert(PlaylistEntity(name = playlistName.trim()))
                                            playlists = playlistDao.all()
                                            playlistName = ""
                                            showCreate = false
                                        }
                                    }) { Text("Create") }
                                },
                                dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } }
                            )
                        }
                        else -> {
                            Text("PLAYBACK", color = Mint, style = MaterialTheme.typography.labelLarge)
                            Text("Crossfade", style = MaterialTheme.typography.titleLarge)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = crossfade, onCheckedChange = { crossfade = it })
                                Text(if (crossfade) "Enabled" else "Disabled")
                            }
                            Text("Duration: ${fadeSeconds.toInt()} seconds")
                            Slider(value = fadeSeconds, onValueChange = {
                                fadeSeconds = it
                                engine.crossfadeMs = (it * 1000).toLong()
                            }, valueRange = 0f..12f)
                            Text("Music source: Music/ only", color = Color.LightGray)
                        }
                    }
                    selected?.let { track ->
                        Card(Modifier.fillMaxWidth().padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(track.title, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text(track.artist, color = Color.LightGray, maxLines = 1)
                                }
                                IconButton(onClick = { if (engine.isPlaying()) engine.pause() else engine.resume() }) {
                                    Icon(Icons.Default.PlayArrow, "Play or pause", tint = Mint)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun TrackRow(track: Track, isSelected: Boolean, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.MusicNote, null, tint = if (isSelected) Mint else Color.LightGray)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(track.artist, color = Color.LightGray, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            if (isSelected) Icon(Icons.Default.GraphicEq, null, tint = Mint)
        }
    }

    override fun onDestroy() {
        engine.release()
        super.onDestroy()
    }
}
